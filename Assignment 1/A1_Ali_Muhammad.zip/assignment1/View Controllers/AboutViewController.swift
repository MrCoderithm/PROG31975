//
//  ViewController.swift
//  assignment1
//
//  Created by Ali Muhammad on 2019-09-14.
//  Copyright © 2019 Ali Muhammad. All rights reserved.
//


import UIKit

class GameViewController: UIViewController {
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
