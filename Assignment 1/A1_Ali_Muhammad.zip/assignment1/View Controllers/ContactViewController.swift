//
//  ViewController.swift
//  assignment1
//
//  Created by Ali Muhammad on 2019-09-14.
//  Copyright © 2019 Ali Muhammad. All rights reserved.
//

import UIKit

class ContactViewController: UIViewController, UITextFieldDelegate, UIWebViewDelegate  {
    
    // Step 2 - declare the following variables and connect them
    @IBOutlet var tfName : UITextField!
    @IBOutlet var tfAddress : UITextField!
    @IBOutlet var tfPhoneNumber : UITextField!
    @IBOutlet var tfEmail : UITextField!
    
    // Step 7 - declare variables for slider and label
    @IBOutlet var slAge : UISlider!
    @IBOutlet var lblAge : UILabel!
    
    @IBOutlet var swGender : UISwitch!
    @IBOutlet var lblGender : UILabel!
    
    
    @objc func stateChanged(switchState: UISwitch) {
        if switchState.isOn {
            lblGender.text = "Male"
        } else {
            lblGender.text = "Female"
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

         swGender.addTarget(self, action: #selector(stateChanged), for: .valueChanged)
        
        // Do any additional setup after loading the view.
        
        // Step 10 - call update at load time
        updateLabel()
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // Step 9 - declare an event handler to fire when
    // slider moves
    @IBAction func sliderValueChanged(_ sender : Any)
    {
        updateLabel()
    }
    
    
    // Step 8 declare a method to update the label with 
    // new slider values.
    func updateLabel()
     {
        let age = slAge.value;
        let strAge = String(format: "%.0f", age)
        lblAge.text = strAge
        
    }
    
    
    // Step 6 - declare event handler to save data
    // and pop up alert "are you sure?"
    @IBAction func updateLabels(_ sender : Any)
    {
        
        let alert = UIAlertController(title: "Thank You", message: "User: \(tfName.text!) with Email: \(tfEmail.text!) for your time ", preferredStyle: .alert)
        
        // note the yes button has a handler declared inline
        let okayAction = UIAlertAction(title: "Back To Home Page", style: .default, handler: {(alert: UIAlertAction!) in
            self.doTheUpdate()
            self.dismiss(animated: true, completion: nil)

        })

        // join button to alert box
        alert.addAction(okayAction)
//        alert.addAction(noAction)
        
        // Picard - "make it so"
        present(alert, animated: true)
    }
    
    
    
    // Step 7 - declare a method to save the data into a
    // seperate object
    // Step 7b - create a new file of type NSObject
    func doTheUpdate()
    {
        let data : Data = .init()
        
        data.initWithStuff(theName: tfName.text!, theEmail: tfEmail.text!)
                
//        lbName.text = data.savedName
//        lbEmail.text = data.savedEmail
        
    }
    
    
    
}
