//
//  ViewController.swift
//  assignment1
//
//  Created by Ali Muhammad on 2019-09-14.
//  Copyright © 2019 Ali Muhammad. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func unwindToHomeViewController(segue: UIStoryboardSegue)
    {
        
    }


}

