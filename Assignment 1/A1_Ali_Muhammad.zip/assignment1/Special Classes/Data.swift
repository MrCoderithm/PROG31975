//
//  ViewController.swift
//  assignment1
//
//  Created by Ali Muhammad on 2019-09-14.
//  Copyright © 2019 Ali Muhammad. All rights reserved.
//

import UIKit

// Step 7c - declare the Data object as follows
class Data: NSObject {

    var savedName : String?
    var savedEmail : String?
    
    
    func initWithStuff(theName : String, theEmail : String)
    {
        savedName = theName
        savedEmail = theEmail
    }
}
