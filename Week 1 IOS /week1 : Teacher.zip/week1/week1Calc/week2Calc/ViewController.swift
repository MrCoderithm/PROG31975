//
//  ViewController.swift
//  week2Calc
//
//  Created by Jawaad Sheikh on 2017-06-06.
//  Copyright © 2017 Jawaad Sheikh. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // step 0 - create storyboard as illustrated
    // step 1 - define the following variables
    // note that lets are constants and vars are variables
    let PLUS = 0
    let MINUS = 1
    let MULTIPLY = 2
    let DIVIDE = 3
    
    @IBOutlet var lblText : UILabel!
    
    var operand : NSInteger = 0
    var answer : Double = 0.0
    var num1 : NSInteger = 0
    var num2 : NSInteger = 0
    
    var theNumber : String = "0"
 
    @IBAction func pressNum(sender : UIButton)
    {
        if (sender.tag >= 0 && sender.tag <= 9)
        {
            theNumber += String(sender.tag)
            printNumber()
        }
        
        
    }
    // step 3 - init your variable values
    // some seem unnecessary but illustrates viewDidLoad()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        theNumber = "0"
        num1 = 0
        num2 = 0
        answer = 0.0
        operand = PLUS
        
        printNumber()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // step 5 - save the first number
    // should execute upon clicking an operand (step 6)
    func saveNum1()
    {
        num1 = Int(theNumber)!
        theNumber = "0"
        printNumber()
    }
    
    // step 3b - create a seperate method for printing number
    func printNumber()
    {
        lblText.text = theNumber
    }
    
    // step 7 - implement the equal sign
    @IBAction func calculate(_ sender: Any)
    {
        num2 = Int(theNumber)!
        
        if(operand == PLUS)
        {
            answer = Double(num1 + num2)
        }
        
        if(operand == MINUS)
        {
            answer = Double(num1 - num2)
        }
        
        if(operand == MULTIPLY)
        {
            answer = Double(num1 * num2)
        }
        
        if(operand == DIVIDE)
        {
            // step 7c - account for divide by zero
            if(num2 == 0)
            {
                // step 7e implement an alert box to indicate
                // error
                
                // declare an alert box object
                let alert = UIAlertController(title: "Error", message: "Cannot Divide By Zero", preferredStyle: .alert)
                
                // declare a alert button
                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
                
                // join button to alert box
                alert.addAction(cancelAction)
                
                // Picard - "make it so"
                present(alert, animated: true)
                
            }
            else
            {
                // step 7d - if ok, then do divide
                answer = Double(num1) / Double(num2)
            }
        }
        
        finishAnswer()
    }
    
    // step 7b - cleaning up
    func finishAnswer()
    {
        theNumber = String(answer)
        num1 = 0
        num2 = 0
        answer = 0.0
        operand = PLUS
        printNumber()
    }
    
    @IBAction func clearNum(_ sender: Any)
    {
        theNumber = "0"
        printNumber()
    }
    
    // step 6 - create event handlers for operands
    @IBAction func setPlus(_ sender: Any)
    {
        operand = PLUS
        saveNum1()
    }
    
    @IBAction func setMinus(_ sender: Any)
    {
        operand = MINUS
        saveNum1()
    }
    
    @IBAction func setMultiply(_ sender: Any)
    {
        operand = MULTIPLY
        saveNum1()
    }
    
    @IBAction func setDivide(_ sender: Any)
    {
        operand = DIVIDE
        saveNum1()
    }

    // step 4 - define event handlers for numbers
    // yes this is repetitive and there is a better way
    // but we are starting with practicing getting 
    // handlers down properly
    @IBAction func press1(_ sender: Any)
    {
        theNumber = theNumber + "1";
        printNumber()
    }
    
    @IBAction func press2(_ sender: Any)
    {
        theNumber = theNumber + "2";
        printNumber()
    }
    
    @IBAction func press3(_ sender: Any)
    {
        theNumber = theNumber + "3";
        printNumber()
    }
    
    @IBAction func press4(_ sender: Any)
    {
        theNumber = theNumber + "4";
        printNumber()
    }
    
    @IBAction func press5(_ sender: Any)
    {
        theNumber = theNumber + "5";
        printNumber()
    }
    
    @IBAction func press6(_ sender: Any)
    {
        theNumber = theNumber + "6";
        printNumber()
    }
    
    @IBAction func press7(_ sender: Any)
    {
        theNumber = theNumber + "7";
        printNumber()
    }
    
    @IBAction func press8(_ sender: Any)
    {
        theNumber = theNumber + "8";
        printNumber()
    }
    
    @IBAction func press9(_ sender: Any)
    {
        theNumber = theNumber + "9";
        printNumber()
    }
    
    @IBAction func press0(_ sender: Any)
    {
        theNumber = theNumber + "0";
        printNumber()
    }

}

