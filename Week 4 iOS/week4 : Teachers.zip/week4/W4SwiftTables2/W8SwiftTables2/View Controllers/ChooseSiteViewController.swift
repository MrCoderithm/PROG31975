//
//  ChooseSiteViewController.swift
//  W8SwiftTables2
//
//  Created by Jawaad Sheikh on 2018-03-14.
//  Copyright © 2018 Jawaad Sheikh. All rights reserved.
//

import UIKit

// step 4 - add image files as defined here.
// step 5 - define the following table delegates
class ChooseSiteViewController: UIViewController,UITableViewDataSource, UITableViewDelegate {
    
    // step 6 - define the following arrays for team name, team url and team logo
    var listData = ["Jays", "Leafs", "Raptors", "Marlies", "FC"]
    // : Array / MutableArray inferred
    
    var siteData: [String] = ["http://www.bluejays.com", "http://www.torontomapleleafs.com", "http://www.torontoraptors.com", "http://www.marlies.ca", "http://www.torontofc.ca"]
    
    var imageData: [String] = ["jays.jpg", "leafs.png", "raptors.jpg", "marlies.jpeg", "fc.png"]

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    // step 7 define the following unwind segue
    @IBAction func unwindToChooseSiteViewController(sender : UIStoryboardSegue)
    {
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // step 8 - define table method for number of cells
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listData.count
    }
    
    // step 9 - define table method for cell thickness
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60;
    }
    
    // step 10 - define table method for how each cell should look
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // let tableCell = tableView.dequeueReusableCell(withIdentifier: "cell") ?? UITableViewCell()
        
        // ?? replaces if tablecell == nil block
        
        // step 10b - define SiteCell.swift as UITableViewCell and move there before continuing below
        
        // step 12 - check if cells already defined and a cell is leaving the screen.
        // if it is a newlyloaded view, cell will be instantiated.
        let tableCell : SiteCell = tableView.dequeueReusableCell(withIdentifier: "cell") as? SiteCell ?? SiteCell(style:UITableViewCellStyle.default, reuseIdentifier: "cell")
        
        // step 12b - populate the cell
        let rowNum = indexPath.row
        let team = listData[rowNum]
        let site = siteData[rowNum]
        let imgName = UIImage(named:imageData[rowNum])
        
        tableCell.primaryLabel.text =  team
        tableCell.secondaryLabel.text = site
        tableCell.myImageView.image = imgName
        
        tableCell.accessoryType = .disclosureIndicator
        
        // step 12c - return the cell
        return tableCell
        
    }
    
    
    // step 13 - define the table method for clicking on a cell
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        // step 13b - in AppDelegate define a string called selectedURL
        let mainDelegate = UIApplication.shared.delegate as! AppDelegate
        
        // step 13d - save url
        mainDelegate.selectedURL = siteData[indexPath.row]
        
        // step 13e - move to ViewSiteViewController screen
        // first define "ChooseSegueToView" in SB
        // move on to ViewSiteViewController.swift
        performSegue(withIdentifier: "ChooseSegueToView", sender: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
