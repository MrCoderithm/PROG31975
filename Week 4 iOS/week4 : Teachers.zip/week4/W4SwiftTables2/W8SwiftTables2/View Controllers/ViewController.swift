//
//  ViewController.swift
//  W8SwiftTables2
//
//  Created by Jawaad Sheikh on 2018-03-14.
//  Copyright © 2018 Jawaad Sheikh. All rights reserved.
//

import UIKit

// step 1 - create storyboard as outlined
class ViewController: UIViewController {

    // step 2 - add the following unwind segue method
    // step 3 - create ChooseSiteViewController.swift and move there
    @IBAction func unwindToHomeViewController(sender : UIStoryboardSegue)
    {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

