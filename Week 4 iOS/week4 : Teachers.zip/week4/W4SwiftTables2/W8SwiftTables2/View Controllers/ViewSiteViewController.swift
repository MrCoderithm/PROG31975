//
//  ViewSiteViewController.swift
//  W8SwiftTables2
//
//  Created by Jawaad Sheikh on 2018-03-14.
//  Copyright © 2018 Jawaad Sheikh. All rights reserved.
//

import UIKit
import WebKit

// step 14 - before continuing - return to SB and connect all items, delegates, segues, etc
// step 14b - define "ChooseSegueToView" for segue between ChooseSite and ViewSite pages

// step 15 - add WKNavigationDelegate
class ViewSiteViewController: UIViewController,WKNavigationDelegate {

    // step 16 - define WKWebView and Activity Indicator and connect them in SB
    @IBOutlet var webView : WKWebView!
    @IBOutlet var activity : UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        // step 17 - display URL saved in AppDelegate
        let mainDelegate = UIApplication.shared.delegate as! AppDelegate
        let urlAddress = URL(string: mainDelegate.selectedURL)
        let url = URLRequest(url: urlAddress!)
        webView.load(url as URLRequest)
        webView.navigationDelegate = self
    }

    // step 18 - define WKWebView support methods for loading and finishing a web request
    
    // step 19 - connect anything remaining in SB and done.
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        
        activity.startAnimating()
        activity.isHidden = false
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        
        activity.stopAnimating()
        activity.isHidden =  true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
