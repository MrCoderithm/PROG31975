//
//  ViewController.swift
//  W8SwiftTables
//
//  Created by Jawaad Sheikh on 2018-03-14.
//  Copyright © 2018 Jawaad Sheikh. All rights reserved.
//

import UIKit

// step 1 - create storyboard as designed.

class ViewController: UIViewController {

    // step 2 - add unwind segue
    // step 3 - add new View Controller object "MyTableViewController" and move there
    @IBAction func unwindToThisViewController(sender : UIStoryboardSegue)
    {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

