//
//  MyTableViewController.swift
//  W8SwiftTables
//
//  Created by Jawaad Sheikh on 2018-03-14.
//  Copyright © 2018 Jawaad Sheikh. All rights reserved.
//

import UIKit

// step 4 - add the following table delegates
class MyTableViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    // step 5 - declare array for data
    var listData : Array<String> = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // step 5b - define array (could be done above too)
        listData = ["Munkee", "Dunkee", "Laamaa", "Yotee", "Yeenah", "Waalaa", "Heetah", "Ayon"]
        // Do any additional setup after loading the view.
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // MARK: - Table Methods
    
    // step 6 - define Table Delegate method for number of cells to instantiate
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listData.count
    }

    // step 7 - define Table Delegate method for height for each cell
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }

    // step 8 - define how each cell should look and its data
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tableCell = tableView.dequeueReusableCell(withIdentifier: "cell") ?? UITableViewCell()
        
        let rowNum = indexPath.row
        tableCell.textLabel?.text = listData[rowNum]
        
        tableCell.textLabel?.font = UIFont.systemFont(ofSize: 50, weight: .bold)
        tableCell.accessoryType = .disclosureIndicator
        
        return tableCell
        
    }
    
    // step 9 making cells editable
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    // step 9b rigth swipe actions
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
    
        let more = UITableViewRowAction(style: .normal, title: "More", handler:
        {  action, index in
            print("More button tapped")
        }
        )
        more.backgroundColor = .lightGray
        
        let favourite = UITableViewRowAction(style: .normal, title: "Favourite", handler:
        { action, index in
            print("Favourites button tapped")
        }
        )
        favourite.backgroundColor = .orange
        
        let share = UITableViewRowAction(style: .normal, title: "Share", handler:
        { action, index in
            print("Share button tapped")
        }
        )
        share.backgroundColor = .blue
        
       
        return [share, favourite, more]
    }
    
    // step 9c left swipe actions
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
 
        let modifyAction = UIContextualAction(style: .normal, title: "Modify", handler:
        { ac, view, success in
            print("Modify button tapped")
            success(true)
        }
        )
        
       
         modifyAction.backgroundColor = .red
        
        return UISwipeActionsConfiguration(actions: [modifyAction])
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
